# modnotes
Autosuspend plugin for Oxwall. Automatically suspends users whose profile has been flagged a certain number of times.
